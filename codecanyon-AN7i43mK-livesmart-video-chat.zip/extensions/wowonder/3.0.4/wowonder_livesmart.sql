INSERT INTO `Wo_Config` (`name`, `value`) VALUES
('livesmart_url', '');